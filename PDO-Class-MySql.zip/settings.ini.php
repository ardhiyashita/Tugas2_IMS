;<?php return; ?>
[SQL]
host = 127.0.0.1
user = root
password = 123
dbname = db_toko
